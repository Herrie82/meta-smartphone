# Android 9 services for a legacy vendor under the 16.0 GSI

The compiled parts of what the Android 16 GSI + Android 9 vendor combination needs, for any pre-Treble Halium 9 device (hammerhead, mako, tenderloin): none of them is specific to a device, they call the vendor's own legacy HAL modules. The text parts
(init scripts, wrapper scripts, the shim source) are plain files next to the recipe in the layer.

Built from the Halium 9 tree at `/media/herrie/HaliumDisk/9.0` (not a git checkout on this machine, so no revision is
recorded here) with the scripts in `build-scripts/`, all 32-bit (`out-arm32`):

| files | script |
| --- | --- |
| `bin/hw/android.hardware.graphics.composer@2.1-service`, `...allocator@2.0-service` | `claude-build-gfx-services-arm32-a9.sh` |
| `bin/hw/rild`, `lib/libril.so`, `lib/librilutils.so`, `bin/hw/android.hardware.camera.provider@2.4-service` | `claude-build-ril-camera-arm32-a9.sh` |
| `bin/hw/android.hardware.media.omx@1.0-service`, `lib/libavservices_minijail_vendor.so` | `claude-build-omx-arm32-a9.sh` |
| `lib/libpermissioncache_shim.so` | `permissioncache_shim.c` + `shim.map` in the layer: `gcc -O2 -fPIC -nostdlib -shared -Wl,-soname,libpermissioncache_shim.so -Wl,--hash-style=both -Wl,-z,noexecstack -Wl,--version-script=shim.map` |
| `bin/crash_dump_noop` | hand-assembled static ELF that exits at once (see `crash-dump-noop.rc` in the layer) |

`MANIFEST.sha256` lists every file; check it after unpacking.
