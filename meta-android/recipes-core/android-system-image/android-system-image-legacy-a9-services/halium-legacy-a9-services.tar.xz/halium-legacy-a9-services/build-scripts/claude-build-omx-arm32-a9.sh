#!/bin/bash
# Build the HIDL graphics service wrappers against Android 9's own libraries, 32-bit,
# for pre-Treble hammerhead/mako/tenderloin vendors (VNDK 28). The 16.0 tree's builds
# use libc++ namespace std::__1 and cannot link against the VNDK-28 snapshot.
# lineage_halium_arm64 with 32-bit executables: the Lineage soong rules need a Lineage product,
# and aosp_arm fails on KERNEL_MAKE_FLAGS. Separate OUT_DIR so the tissot/sargo outputs in out/ are left alone.
set +u
cd /media/herrie/HaliumDisk/9.0 || exit 1
unset -f grep 2>/dev/null
export LC_ALL=C
export PATH="/media/herrie/HaliumDisk/9.0/.py2shim:$PATH"
export OUT_DIR=/media/herrie/HaliumDisk/9.0/out-arm32
ulimit -n 65536 2>/dev/null
renice -n 10 -p $$ >/dev/null 2>&1
LOG=/media/herrie/HaliumDisk/9.0-omx-arm32-build.log
: > "$LOG"
echo "===== BUILD omx service aosp_arm (A9) @ $(date -u +%F_%H:%M:%S) =====" | tee -a "$LOG"
source build/envsetup.sh >>"$LOG" 2>&1
lunch lineage_halium_arm64-userdebug >>"$LOG" 2>&1 || { echo "LUNCH FAILED" | tee -a "$LOG"; tail -n 20 "$LOG"; exit 2; }
m -j 8 TARGET_PREFER_32_BIT_EXECUTABLES=true android.hardware.media.omx@1.0-service >>"$LOG" 2>&1
rc=$?
echo "A9-OMX-BUILD-EXIT=$rc" | tee -a "$LOG"
find "$OUT_DIR/target/product" \( -name 'android.hardware.media.omx@1.0-service*' -o -name 'mediacodec*.policy' \) -type f -not -path '*/symbols/*' 2>/dev/null | tee -a "$LOG"
echo "===== DONE @ $(date -u +%F_%H:%M:%S) =====" | tee -a "$LOG"
