# tenderloin-media

The HP TouchPad's hardware video encoders and decoders for the LuneOS GSI port (tenderloin-halium):
the Qualcomm OMX core, the legacy vidc encoder and decoder components and the stagefright plugin that
loads them, all 32-bit ARMv7. Installed into the vendor image by android-system-image-tenderloin-halium-gsi.bb
(HALIUM_LEGACY_EXTRA_FILES), where the vendor's android.hardware.media.omx@1.0-service picks up
libstagefrighthw.so.

## Built in the Android 9 tree

`/media/herrie/HaliumDisk/9.0`, product `lineage_halium_arm64-userdebug` with
`TARGET_PREFER_32_BIT_EXECUTABLES=true` and `HALIUM_2ND_ARCH_ARMV7=true`, `OUT_DIR=out-armv7`, as the
camera (device/hp/tenderloin-camera), from `device/hp/tenderloin-media`:
`m libOmxCore libOmxVenc libOmxVdec libstagefrighthw libc2dcolorconvert`.

| File | Module | Source |
|---|---|---|
| lib/libOmxCore.so | libOmxCore | LineageOS/android_hardware_qcom_media ef30d8cfa9082e9953d4b2657e6f2f9ed44db294, msm8960/mm-core (registry src/8660) |
| lib/libOmxVenc.so | libOmxVenc | same, msm8960/mm-video-legacy/vidc/venc |
| lib/libOmxVdec.so | libOmxVdec | same, msm8960/mm-video-legacy/vidc/vdec |
| lib/libdivxdrmdecrypt.so | libdivxdrmdecrypt | same, msm8960/mm-video-legacy/DivxDrmDecrypt (libOmxVdec links it) |
| lib/libstagefrighthw.so | libstagefrighthw | same, msm8960/libstagefrighthw |
| lib/libc2dcolorconvert.so | libc2dcolorconvert | same, msm8960/libc2dcolorconvert |
| etc/media_codecs.xml | | the AVC, MPEG-4 and H.263 encoders and decoders |

The four directories were copied into device/hp/tenderloin-media; build/tenderloin-media-vs-msm8960.diff
is every change, build/Android.mk the top makefile:

- the makefiles test TENDERLOIN_MEDIA_PLATFORM (msm8660) instead of TARGET_BOARD_PLATFORM, and
  `$(call project-path-for,qcom-media)` is the module's own path, so the generic product need not claim
  the platform;
- no LOCAL_COPY_HEADERS (Android 9 allows it only in VNDK vendor modules); the libraries include
  mm-core/inc by path;
- kernel headers from kernel-headers/ (msm_vidc_enc.h, msm_vidc_dec.h, ion.h, msm_ion.h, msm_mdp.h,
  msm_kgsl.h from `make headers_install` of shr-distribution/linux herrie/tenderloin-3.4-gsi) instead of
  Lineage's generated_kernel_headers; display headers from hardware/qcom/display-caf
  b90f1719c1adbdf1644ddba0c061c045a79df94e (msm8960 libgralloc, libqdutils; c2d2.h from msm8952
  libcopybit);
- the encoder allocates from ION (-DUSE_ION; TARGET_USES_ION is a device variable this product lacks),
  and the 3.4 kernel's struct ion_allocation_data calls the field heap_mask, not heap_id_mask;
- LOCAL_MULTILIB := 32 everywhere: the code is 32-bit only;
- the decoder builds without the display's libqservice and libqdMetaData (TENDERLOIN_NO_QSERVICE,
  TENDERLOIN_NO_QDMETADATA): their only uses are the display's secure mode for protected content and the
  buffer geometry metadata of a newer gralloc, neither of which the vendor has (its libqdutils exports no
  setMetaData); GRALLOC_USAGE_PRIVATE_CP_BUFFER, which the msm8960 gralloc_priv.h lacks, is 0.
- the decoder runs without an IOMMU (the tenderloin 3.4 kernel has none): its non-secure ION
  allocations also ask for the multimedia CP heap, and the output buffers it requests from gralloc use
  GRALLOC_USAGE_PRIVATE_MM_HEAP instead of IOMMU_HEAP | PRIVATE_UNCACHED (the Gralloc2 wrapper of the
  Android 16 userspace rejects PRIVATE_UNCACHED as an invalid bit);
- the decoder keeps the client's input buffer count when the resolution changes: the driver recomputes
  its input requirements for the new size and drops the count back to 2, so the third input buffer
  overflowed the driver's pool ("Buffer pool is full");
- native (gralloc) output buffers are registered with their whole gralloc size: gralloc rounds the size
  up, and ION refuses a mapping shorter than the buffer ("iova length is not at least buffer size").
- the encoder's ION buffers are uncached (VENC_ION_BUFFER_FLAGS 0 instead of ION_FLAG_CACHED): the
  component does no cache maintenance on them, and with cached output buffers the bitstream read back
  after the core's DMA was largely stale (green frames with intact headers);
- in metadata mode (camera recording, TENDERLOIN_VENC_META_COPY) the encoder allocates and registers
  its own uncached ION input buffer per input index once, and copies each gralloc frame into it,
  instead of registering every gralloc buffer with the driver for the frame it carries: registered per
  frame, the frames never reached the core and every encoded frame came out green. The copy buffers
  are freed with their input buffer; before that, each recording left them in the multimedia heap
  until the camera could no longer allocate its video buffers.

libc2dcolorconvert dlopen()s libC2D2.so, which the vendor image does not have; the encoder
needs it only for opaque or RGB input, not for camera frames.

## Status

H.264 decoding runs (droidvdec: a 640x480 clip, all 299 frames, output NV12_64Z32). Hardware H.264
camera recording runs (640x480, 15 fps, with AAC audio, from the camera app through droidcamsrc's
recorder); it needs buffer-queue video mode in the GSI's HAL1 CameraClient, which Android 16's
CameraSource requires. Two recordings in a row leave the multimedia ION heap as empty as before.
