# tenderloin-camera

The HP TouchPad's legacy camera for the LuneOS GSI port (tenderloin-halium): the HAL1 camera module,
the Android 9 HIDL camera provider and device implementations it is served through, and the HP
camera blobs the HAL loads. All 32-bit ARM. Installed into the vendor image by
android-system-image-tenderloin-halium-gsi.bb (HALIUM_LEGACY_EXTRA_FILES).

## Built in the Android 9 tree

`/media/herrie/HaliumDisk/9.0`, product `lineage_halium_arm64-userdebug` with
`TARGET_PREFER_32_BIT_EXECUTABLES=true` and `HALIUM_2ND_ARCH_ARMV7=true`, `OUT_DIR=out-armv7`
(build/build-a9-camera.sh). The variable switches the 32-bit side from armv8-a to armv7-a-neon /
cortex-a9 in device/halium/halium_arm64/BoardConfig.mk: armv8-a AArch32 code uses ARMv8-only
instructions (ldab in a static-init guard) and the provider died with SIGILL on the TouchPad's
ARMv7 Scorpion. Every ELF here is Tag_CPU_arch v7 with no lda/stl instructions.

| File | Module | Source |
|---|---|---|
| lib/hw/camera.msm8660.so | camera.msm8660 | herrie82/android_device_hp_tenderloin-common halium-9.0 e63982116db5c42ad8f30d4e1eacb55998736d86, camerahal/ |
| lib/libbinder_shim.so | libbinder_shim | same commit, libshims/ (MemoryHeapPmem) |
| lib/hw/android.hardware.camera.provider@2.4-impl.so | android.hardware.camera.provider@2.4-impl | LineageOS/android_hardware_interfaces 247f33da70920c5d79765faab67ee3191133723c |
| lib/camera.device@{1.0,3.2,3.3,3.4,3.4-external}-impl.so | camera.device@*-impl | same |
| bin/hw/android.hardware.camera.provider@2.4-service | android.hardware.camera.provider@2.4-service | same; the shared A9 services copy is armv8-a |

build/Android.mk is the makefile the two tenderloin modules were built with, from
`device/hp/tenderloin-camera` in that tree. It links the vendor image's own libgenlock.so by file,
and includes only the kernel uapi headers the HAL needs (linux/android_pmem.h, ion.h, msm_ion.h,
msm_mdp.h, media/msm_camera.h, msm_camera-tenderloin.h) from `make headers_install` of the
tenderloin 3.4 kernel (shr-distribution/linux herrie/tenderloin-3.4-gsi 7a6a4bdce76e). Gralloc and
genlock headers: hardware/qcom/display-caf/msm8960 b90f1719c1adbdf1644ddba0c061c045a79df94e.

## Changes to the tenderloin-common HAL

build/camerahal-*.diff, applied to camerahal/ of the commit above:

- 0001: drop the stat("/dev/oncrpc") gate in createInstance. It belongs to the 7x27 stacks that
  reach the camera over the ONCRPC router; the 3.4 kernel has no oncrpc, and liboemcamera opens
  only the msm_camera nodes, pmem_adsp, video20 and the framebuffer.
- 0002: load liboemcamera.so at 0x67700000. The blob is prelinked there ("PRE " tag) and has no
  R_ARM_RELATIVE relocations, so its GOT holds absolute addresses; loaded elsewhere, the mm-camera
  thread faults on the first store through one (GOT slot 0x4939c = 0x67786558, its .bss). The HAL
  reserves that span and loads the library into it with android_dlopen_ext
  (ANDROID_DLEXT_RESERVED_ADDRESS).
- 0003: keep liboemcamera loaded for the life of the process. After a dlclose the reserved span was
  still mapped and the next open could not reserve it; the failure path then called
  LINK_mm_camera_destroy into the unloaded copy and crashed. Call it only when loaded.
- 0004: no GRALLOC_USAGE_PRIVATE_UNCACHED on the preview buffers. Android 16's Gralloc2 wrapper
  rejects the bit ("invalid usage bits 0x2000000") and the preview gets no buffer.

- 0005: use the span liboemcamera_reserve.so claimed (looked up with dlopen(RTLD_NOLOAD) + dlsym),
  and only try to claim it itself when that is not there.

## liboemcamera_reserve.so

build/oemcamera_reserve.c, preloaded first into the camera provider by camera-provider-start.sh (in the
layer): a constructor that claims 0x67700000-0x67790000 with a PROT_NONE mapping and exports
tenderloin_oemcamera_reservation(). Built like the shared permission-cache shim, with the OE cross GCC:
`arm-webos-linux-gnueabi-gcc -O2 -fPIC -nostdlib -shared -marm -Wl,-soname,liboemcamera_reserve.so
-Wl,--hash-style=both -Wl,-z,noexecstack`. The start script also runs the provider with an unlimited
stack, which makes the 3.4 kernel use the bottom-up mmap layout, so nothing is mapped there first.

## Blobs

From TheMuppets/proprietary_vendor_hp, branch ics, 832536218f441ed60542ec701b86e2b4a1446d0f,
tenderloin/proprietary/lib/: liboemcamera.so (dlopen()ed by the HAL), libmmjpeg.so, libmmipl.so,
libgemini.so. liboemcamera, libmmjpeg and libgemini are byte-identical to the copies in
herrie82/android_vendor_hp-1 halium-9.0, which lacks libmmipl.so.

## Status

Never run on the 3.4 kernel before: the HAL's own README says "NOT WORKING YET". The sensor
(MT9M113 on i2c-1 0x78) probes and the legacy msm_camera nodes exist.
